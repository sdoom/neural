﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Odbc;
namespace DataConsolidation
{
    public class hiveSql
    {
        public class HiveOdbcClient : IDisposable
        {
            OdbcConnection _conn;

            public HiveOdbcClient(string dns)
            {
                _conn = new OdbcConnection(dns);
                _conn.Open();
            }

            public void Excute(string sql)
            {
                OdbcCommand cmd = new OdbcCommand(sql, _conn);
                cmd.ExecuteNonQuery();
            }

            public DataTable Query(string sql)
            {
                DataTable table = new DataTable();
                OdbcDataAdapter adapter = new OdbcDataAdapter(sql, _conn);
                adapter.Fill(table);
                return table;
            }

            public void Dispose()
            {
                if (_conn != null)
                {
                    _conn.Dispose();
                }
            }
        }
    }
}
