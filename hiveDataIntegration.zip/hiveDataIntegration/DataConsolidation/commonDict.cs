﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataConsolidation
{
    public class commonDict
    {
        public Dictionary<string, string> DataDict()
        {
            Dictionary<string, string> DataDict = new Dictionary<string, string>(150);
            DataDict.Add("jh", "井号");
            DataDict.Add("xh", "层号");
            DataDict.Add("djsd1", "顶界深度");
            DataDict.Add("djsd2", "底界深度");
            DataDict.Add("qxsd", "取芯深度");
            DataDict.Add("dys", "岩心颜色");
            DataDict.Add("dysmc ", "岩心岩性代码");
            DataDict.Add("dhyjb", "含油级别");




            return DataDict;

        }
        public void SetHeaderText(DataGridView dgvJ)
        {
            dgvJ.Columns[0].HeaderText = "编号";      //dataGridView1.Columns[0].Width = 200; dataGridView1.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvJ.Columns[1].HeaderText = "岩性代码";
        }
    }
}
