﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using DAL;
using System.Windows.Forms;
//using ClassLibrary1;
namespace DataConsolidation
{
    public class DataAnalysis
    {

        public void Analysis(string meta, DataGridView DatGrid,int rows)
        {
            string tempText = meta;
            //MessageBox.Show(tempText);
            string[] wellInf = tempText.Split('\t');

            DatGrid.ColumnCount = wellInf.Count();
            if (rows == 1)
            {
                DatGrid.Rows.Add();
            }

            DatGrid.Rows.Add();
            int j = 0;
            foreach (var item in wellInf)
            {
                DatGrid.Rows[rows].Cells[j].Value = item;
                j++;
            }
            return;

        }
        


        public void Insert(DataGridView DatGrid,string table_name)
        {
            
            commonDict cds = new commonDict();
            Dictionary<string, string>  dicts = cds.DataDict();
            List<int> lineCount = new List<int>(20);
            List<string> usefulFields = new List<string>();
            string SQLcmd = "";
            //string table_name = "";
            string dns = "DSN=dev57;UID=root;PWD=";
            //using (HiveOdbcClient client = new HiveOdbcClient(dns))
            //{


                for (int i = 0; i < DatGrid.Rows[0].Cells.Count; i++)
                {
                    foreach (var item in dicts)
                    {
                        if (DatGrid.Rows[0].Cells[i].Value.ToString() == item.Value)
                        {
                            lineCount.Add(i);
                            usefulFields.Add(item.Key);
                        }
                    }
                }


                for (int row = 3; row < DatGrid.RowCount; row++)
                {
                    SQLcmd = "Insert into " + table_name + " (";
                    foreach (var UsefulColumn in usefulFields)
                    {
                        SQLcmd += UsefulColumn + ",";
                    }
                    SQLcmd = SQLcmd.TrimEnd(',');
                    SQLcmd += ")";
                    SQLcmd += " VALUES(";
                    foreach (var index in lineCount)
                    {
                        SQLcmd += "'" + DatGrid.Rows[row].Cells[index].Value.ToString() + "',";
                    }
                    SQLcmd = SQLcmd.TrimEnd(',');

                    SQLcmd += ") ";
                    //MessageBox.Show(SQLcmd);
                    //client.Excute(SQLcmd);

                    //MessageBox.Show("sucess");
                    //SqlHelper.ExecuteNonQuery(SQLcmd);
                    //Insert into az14_ht (jh,qxsd,dys,dysmc ,dhyjb) VALUES('敖163','1306.6','3.7','s79','yj');


                }
                //client.Dispose();


            //}

        }

    }
}
