﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataConsolidation
{
    public class commonFunc
    {
        string dns = "DSN=dev57;UID=root;PWD=111111";
        public void execCretaeDatabase(string databaseName)
        {

            using (hiveSql.HiveOdbcClient client = new hiveSql.HiveOdbcClient(dns))
            {
                string sql = "create database " + databaseName;
                client.Excute(sql);
            }

        }
        public void execCretaeTable(string tableName,string columns,string databaseName)
        {

            using (hiveSql.HiveOdbcClient client = new hiveSql.HiveOdbcClient(dns))
            {
                string sql = "use " + databaseName +  " create table " + tableName + "(" + columns + ")";
                client.Excute(sql);
            }
        }
        public void execDeleteTable(string databaseName,string tableName)
        {
            using (hiveSql.HiveOdbcClient client = new hiveSql.HiveOdbcClient(dns))
            {
                string sql = "use " + databaseName + " truncate table " + tableName;
                client.Excute(sql);
            }
        }
        public void execQueryTable(string databaseName,string tableName)
        {
            using (hiveSql.HiveOdbcClient client = new hiveSql.HiveOdbcClient(dns))
            {
                string sql = "use " + databaseName + " select * from " + tableName;
                client.Query(sql);
            }
        }
        public void execViewTable(string databaseName)
        {
            using (hiveSql.HiveOdbcClient client = new hiveSql.HiveOdbcClient(dns))
            {
                string sql = "use " + databaseName + " show tables";
                client.Query(sql);
            }
        }
        public void ftp(string host)
        {

        }


    }


    }
    



        



           
    

