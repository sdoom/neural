﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;
using System.Windows.Forms;
using System.Data;
using System.Xml.Linq;
using Model;

namespace DataConsolidation
{
    public class SaveAsXML
    {
        public void CreateNode(XmlDocument xmlDoc, XmlNode parentNode, string name, string value)
        {
            XmlNode node = xmlDoc.CreateNode(XmlNodeType.Element, name, null);
            node.InnerText = value;
            parentNode.AppendChild(node);

        }
        
        //这个方法是将神经网络的参数存为xml文件
        public void SaveToXml(string trainAlgorithm, string inputNode, string hiddenNum, string hiddenNode, string ouputNode, string rate, string trainDataNum)
        {
            XmlDocument xmlDoc = new XmlDocument();
            XmlNode node = xmlDoc.CreateXmlDeclaration("1.0", "utf-8", "");
            xmlDoc.AppendChild(node);
            XmlNode root = xmlDoc.CreateElement("root");
            xmlDoc.AppendChild(root);
            CreateNode(xmlDoc, root, "训练算法选择", trainAlgorithm);
            CreateNode(xmlDoc, root, "输入层节点", inputNode);
            CreateNode(xmlDoc, root, "隐藏层层数", hiddenNum);
            CreateNode(xmlDoc, root, "隐藏层节点", hiddenNode);
            CreateNode(xmlDoc, root, "输出层节点", ouputNode);
            CreateNode(xmlDoc, root, "学习率", rate);
            CreateNode(xmlDoc, root, "训练数据迭代次数", trainDataNum);
            xmlDoc.Save("D://data2.xml");
            MessageBox.Show("保存成功");
        }       

        // 新建一个xml文件
        public void CreateXml(string path)
        {
            if(File.Exists(path))
            {
                MessageBox.Show("已经存在该文件");
            }
            else
            {
                XmlDocument xmlDoc = new XmlDocument();
                XmlNode node = xmlDoc.CreateXmlDeclaration("1.0", "utf-8", "");
                xmlDoc.AppendChild(node);
                XmlNode root = xmlDoc.CreateElement("root");
                xmlDoc.AppendChild(root);
                //XmlElement xe1 = xmlDoc.CreateElement("yx");
                //root.AppendChild(xe1);
                xmlDoc.Save(path);
                MessageBox.Show("新建成功！");
                return;
            }
            
        } 
        public void DatagridviewToXml(DataGridView dgv,string path)
        {
            XmlDocument xmlDoc = new XmlDocument();

            if(File.Exists(path))
            {
                xmlDoc.Load(path);
                
                XmlNode xn = xmlDoc.SelectSingleNode("/root");

                for (int i = 0; i < dgv.RowCount; i++)
                {
                    if (dgv.Rows[i].IsNewRow) break;
                    XmlElement xe2 = xmlDoc.CreateElement("item");
                    for (int j = 0; j < dgv.ColumnCount; j++)
                    {
                        xe2.SetAttribute(dgv.Columns[j].HeaderText.Trim(), dgv[j, i].Value.ToString().Trim());
                    }
                    xn.AppendChild(xe2);
                }

                XmlNode n = xmlDoc.SelectSingleNode("/root");

                xmlDoc.Save(path);
                MessageBox.Show("保存成功！");
            }
            else
            {
                MessageBox.Show("请新建一个xml文件！");
            }          
        }
             
        // 给xml文件中添加加记录
        public void InsertIntoXml(string name, string number,string xmlPath,DataGridView dgv)
        {
            XElement xe = XElement.Load(xmlPath);
            IEnumerable<XElement> elements1 = from ele in xe.Elements("item") select ele;
            XElement item = new XElement("item",new XAttribute("岩性代码",name),new XAttribute("编号",number));
            xe.Add(item);
            xe.Save(xmlPath);
            XmlToDataGridView(xmlPath,dgv);
        }

        //删除xml数据
        public void DeleteXml(string name, string xmlPath, DataGridView dgv)
        {
             XElement xe = XElement.Load(xmlPath);
            if(name != "")
            {
                IEnumerable<XElement> delelement = from ele in xe.Elements("item")
                                                   where ele.Attribute("岩性代码").Value == name
                                                   select ele;
                if(delelement.Count()>0)
                {
                    delelement.First().Remove();
                }
                xe.Save(xmlPath);
                XmlToDataGridView(xmlPath, dgv);
            }
            
        }

        //选中xml文件中的一行，修改
        public void UpdateXml(string name, string number, string xmlPath, DataGridView dgv)
        {
            XElement xe = XElement.Load(xmlPath);
            IEnumerable<XElement> upelement = from ele in xe.Elements("item")
                                               where ele.Attribute("岩性代码").Value == name
                                               select ele;
            if (upelement.Count() > 0)
            {
                XElement newXelment = upelement.First();
                newXelment.SetAttributeValue("岩性代码",name);
                newXelment.SetAttributeValue("编号",number);
            }
            xe.Save(xmlPath);
            XmlToDataGridView(xmlPath, dgv);
        }

        // 将datagridview中选中的一行，给combox赋值
        public void DataGridViewCellClick(ComboBox name, ComboBox number, string xmlPath, DataGridView dgv, DataGridViewCellEventArgs e)
        {
            number.Text = dgv.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
            XElement xe = XElement.Load(xmlPath);
            IEnumerable<XElement> elements = from ele in xe.Elements("item")
                                              where ele.Attribute("编号").Value == number.Text
                                              select ele;
            foreach(XElement element in elements)
            {
                name.Text = element.Attribute("岩性代码").Value;
                number.Text = element.Attribute("编号").Value;
            }

        }

        // 将xml文件绑定到datagridview（查询）
        public void XmlToDataGridView(string XmlFullDir,DataGridView dgv)
        {
            XElement xe = XElement.Load(XmlFullDir);
            DataTable dt = new DataTable();

            if(File.Exists(XmlFullDir))
            {
                List<YXXml> modeList = new List<YXXml>();
                IEnumerable<XElement> elements = from ele in xe.Elements("item") select ele;
                foreach (var ele in elements)
                {
                    YXXml yxXml = new YXXml();
                    yxXml.Name = ele.Attribute("岩性代码").Value;
                    yxXml.Number = ele.Attribute("编号").Value;
                    modeList.Add(yxXml);
                }
                dgv.DataSource = modeList;
            }
            else
            {
                MessageBox.Show("请新建一个xml文件！");
                return;
            }

            //这一段也可以实现
            //DataSet ds = new DataSet();
            //ds.ReadXml(XmlFullDir);
            //dataGridView2.DataSource = ds.Tables[0];
            
        }
    }
}
