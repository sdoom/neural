﻿using DataConsolidation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraBars;

namespace myUI
{
    public partial class OperateXml : Form
    { 
        public OperateXml()
        {
            InitializeComponent();
        }
        public static string path = "D://1.xml";
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            SaveAsXML saveXml = new SaveAsXML();
            saveXml.DataGridViewCellClick(comboBox1, comboBox2, path, dataGridView1, e);
        }

        private void barLargeButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)//查询
        {
            commonDict dgvHeadText = new commonDict();
            SaveAsXML saveXml = new SaveAsXML();
            saveXml.XmlToDataGridView(path, dataGridView1);
            dgvHeadText.SetHeaderText(dataGridView1);
        }

        private void barLargeButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)//添加
        {
            if (Convert.ToString(comboBox1.EditValue) == "" || Convert.ToString(comboBox2.EditValue) == "")
            {
                MessageBox.Show("不能添加空行");
                return;
            }
            SaveAsXML saveXml = new SaveAsXML();
            saveXml.InsertIntoXml(comboBox1.EditValue.ToString(), comboBox2.EditValue.ToString(), path, dataGridView1);
        }

        private void barLargeButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)//修改
        {
            SaveAsXML saveXml = new SaveAsXML();
            //saveXml.UpdateXml(comboBox1.Text.Trim(), comboBox2.Text.Trim(), path, dataGridView1);
            saveXml.DatagridviewToXml(dataGridView1, path);
        }

        private void barLargeButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)//删除
        {
            SaveAsXML saveXml = new SaveAsXML();
            saveXml.DeleteXml(comboBox1.EditValue.ToString(), path, dataGridView1);
        }

        private void barLargeButtonItem5_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)//新建xml文件
        {

            SaveAsXML saveXml = new SaveAsXML();
            saveXml.CreateXml(path);
        }

    }
}
