﻿using DataConsolidation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace myUI
{
    public partial class OperateXml : Form
    {
        public OperateXml()
        {
            InitializeComponent();
        }
        public static string path = "D://1.xml";
        private void button2_Click(object sender, EventArgs e)//新建xml文件
        {
            SaveAsXML saveXml = new SaveAsXML();
            saveXml.CreateXml(path);
        }

        private void button3_Click(object sender, EventArgs e)//查询xml文件
        {
            commonDict dgvHeadText = new commonDict();
            SaveAsXML saveXml = new SaveAsXML();
            saveXml.XmlToDataGridView(path, dataGridView1);
            dgvHeadText.SetHeaderText(dataGridView1);
        }


        private void button4_Click(object sender, EventArgs e)//这是添加功能，添加的combox
        {
            if (comboBox1.Text == "" || comboBox2.Text == "")
            {
                MessageBox.Show("不能添加空行");
                return;
            }
            SaveAsXML saveXml = new SaveAsXML();
            saveXml.InsertIntoXml(comboBox1.Text.Trim(),comboBox2.Text.Trim(),path,dataGridView1);
        }

        private void button5_Click(object sender, EventArgs e)//在combox中修改xml文件
        {
            SaveAsXML saveXml = new SaveAsXML();
            saveXml.UpdateXml(comboBox1.Text.Trim(), comboBox2.Text.Trim(), path, dataGridView1);
        }

        private void button6_Click(object sender, EventArgs e)//删除xml一行记录
        {
            SaveAsXML saveXml = new SaveAsXML();
            saveXml.DeleteXml(comboBox1.Text.Trim(),path,dataGridView1);
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            SaveAsXML saveXml = new SaveAsXML();
            saveXml.DataGridViewCellClick(comboBox1, comboBox2, path, dataGridView1, e);
        }
    }
}
