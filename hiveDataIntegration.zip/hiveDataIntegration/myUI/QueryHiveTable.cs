﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataConsolidation;

namespace myUI
{
    public partial class QueryHiveTable : Form
    {
        public QueryHiveTable()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            commonFunc cf = new commonFunc();
            cf.execQueryTable(comboBox1.Text,comboBox2.Text);
            dataGridView1.DataSource = cf;
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            commonFunc cf = new commonFunc();
            cf.execViewTable(comboBox1.Text);
            dataGridView2.DataSource = cf;
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            commonFunc cf = new commonFunc();
            cf.execDeleteTable(comboBox1.Text,comboBox2.Text);
        }
    }
}
