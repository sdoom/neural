﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataConsolidation;

namespace myUI
{
    public partial class loadTxt : Form
    {
        public loadTxt()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "txt(*.txt)|*.txt|dat(*.dat)|*.dat|las(*.las)|*.las";
            openFileDialog1.InitialDirectory = @"F:\hive";
            openFileDialog1.Title = "请打开一个文件";
            String path = openFileDialog1.FileName;

            FtpClient ftp = new FtpClient(comboBox1.Text, comboBox5.Text, comboBox4.Text);
            


            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //ftp.Upload(openFileDialog1, comboBox6.Text);
            }
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            Point p = groupControl1.Location;
            p.Y = 0 - (int)(e.NewValue);
            groupControl1.Location = p;
            Text = e.OldValue.ToString() + " " + e.NewValue.ToString() + " " + vScrollBar1.Value.ToString();
        }

        private void loadTxt_Load(object sender, EventArgs e)
        {
           
        }


       
    }
}
