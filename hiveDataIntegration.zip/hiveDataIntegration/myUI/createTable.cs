﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataConsolidation;
namespace myUI
{
    public partial class createTable : Form
    {
        public createTable()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            commonFunc cf = new commonFunc();
            cf.execCretaeTable(this.textBox1.Text,this.comboBox2.Text, this.textBox2.Text);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
