﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataConsolidation;

namespace myUI
{
    public partial class Neural : Form
    {
        public Neural()
        {
            InitializeComponent();
        }

        private void Neural_Load(object sender, EventArgs e)
        {

        }

       

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            SaveAsXML saveXml = new SaveAsXML();
            saveXml.SaveToXml(comboBox1.Text, comboBox2.Text, comboBox3.Text, comboBox4.Text, comboBox5.Text, comboBox6.Text, comboBox7.Text);

            //this.Close();
            //return;
        }
    }
}
