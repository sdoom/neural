﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using DataConsolidation;
using myUI;
using DevExpress.XtraTab;
using DevExpress.XtraTab.ViewInfo;

namespace hiveDataIntegration
{
    public partial class Form1 : DevExpress.XtraBars.Ribbon.RibbonForm

    {
        Dictionary<string, XtraTabPage> dictXtraTabPage = new Dictionary<string, XtraTabPage>();
        Dictionary<string, Form> dictXtraForm = new Dictionary<string, Form>();

        DataAnalysis day = new DataAnalysis();
        static string table = "";

        public Form1()
        {
            InitializeComponent();
        }

        public void clear()
        {
            /*this.dataGridView1.DataSource = null;
            this.dataGridView1.Rows.Clear();
            this.dataGridView1.Columns.Clear();*/
        }
        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "txt(*.txt)|*.txt|dat(*.dat)|*.dat|las(*.las)|*.las";


            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //clear();

                StreamReader myReader = new StreamReader(openFileDialog1.FileName, System.Text.Encoding.Default);
                string aFileName = openFileDialog1.FileName;
                string datCell = "";
                int rows = 1;

                while ((datCell = myReader.ReadLine()) != null )
                {
                    if (datCell.Length > 0)
                    {
                        //day.Analysis(datCell,this.dataGridView1,rows);
                        rows++;
                    }
                }
                myReader.Close();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {

        }
        private void ShowMDIForm(string cText, Form frm)
        {
            //判断是否已创建过
            if (dictXtraTabPage.ContainsKey(cText))
            {
                xtraTabControl1.SelectedTabPage = dictXtraTabPage[cText];
                return;
            }
            frm.Visible = true;
            frm.Dock = DockStyle.Fill;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.WindowState = FormWindowState.Maximized;
            frm.TopLevel = false;//注意这里，否则加载不出来

            XtraTabPage xpage = new XtraTabPage();
            xpage.Controls.Add(frm);//添加要增加的控件
            xpage.Text = cText;//添加名称
            xpage.ShowCloseButton = DevExpress.Utils.DefaultBoolean.True;
            xtraTabControl1.TabPages.Add(xpage);
            xtraTabControl1.SelectedTabPage = xpage;//显示该页

            dictXtraTabPage.Add(cText, xpage);//加入XtraTabPage字典
            dictXtraForm.Add(cText, frm);//加入XtraForm字典

        }
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //用户点击单元格，让用户选择对应字段。
            //MessageBox.Show("1");
            choose frm = new choose();
            frm.ShowDialog();
            string replaceTxt = choose.chose_Column;
            //dataGridView1.CurrentCell.Value = replaceTxt;
        }

        private void button2_Click(object sender, EventArgs e)
        {

            
            if (table == null)
            {
                MessageBox.Show("please choose tablename");
                return;
            }
            //day.Insert(this.dataGridView1, table);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //table = this.comboBox1.SelectedItem.ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void barButtonItem5_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form nr = new myUI.Neural();
            ShowMDIForm("神经网参数", nr);
        }

        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form cdb = new CreateDatabase();
            //cdb.Show();
            ShowMDIForm("新建数据库", cdb);
        }

        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form ct = new myUI.createTable();
            ShowMDIForm("新建表", ct);
        }

        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form lt = new myUI.loadTxt();
            ShowMDIForm("选择txt文件", lt);
        }

        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form qht = new myUI.QueryHiveTable();
            ShowMDIForm("查询数据", qht);
        }

        private void barButtonItem6_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        private void xtraTabControl1_CloseButtonClick(object sender, EventArgs e)
        {
            ClosePageButtonEventArgs a = (ClosePageButtonEventArgs)e;
            string cText = a.Page.Text;
            if (dictXtraForm.ContainsKey(cText))
            {
                Form form = dictXtraForm[cText] as Form;
                form.Close();
                form.Dispose();
                dictXtraForm.Remove(cText);
            }
            if (dictXtraTabPage.ContainsKey(cText))
            {
                xtraTabControl1.TabPages.Remove((XtraTabPage)a.Page);
                dictXtraTabPage.Remove(cText);
            }
        }

        private void barButtonItem8_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        private void barButtonItem9_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        private void xtraTabControl1_Click(object sender, EventArgs e)
        {

        }

        private void barButtonItem10_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form operateXml = new myUI.OperateXml();
            ShowMDIForm("操作xml文件", operateXml);
        }
    }
}
