﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hiveDataIntegration
{
    public partial class choose : Form
    {
        public static string chose_Column = "";
        public choose()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            chose_Column = listBox1.SelectedItem.ToString();
            this.Close();
            return;
        }
    }
}
