﻿using System;
using System.Data;
using System.Data.Odbc;

namespace hiveDrive
{
    class Program
    {
        static void Main(string[] args)
        {
            string dns = "DSN=dev57;UID=root;PWD=";
            using (HiveOdbcClient client = new HiveOdbcClient(dns))
            {
                string sql = "create table test1(jh string,js string,dm string,yxmc string) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE ";

                client.Excute(sql);

            }
        }


        public class HiveOdbcClient : IDisposable
        {
            OdbcConnection _conn;

            public HiveOdbcClient(string dns)
            {
                _conn = new OdbcConnection(dns);
                _conn.Open();
            }

            public void Excute(string sql)
            {
                OdbcCommand cmd = new OdbcCommand(sql, _conn);
                cmd.ExecuteNonQuery();
            }

            public DataTable Query(string sql)
            {
                DataTable table = new DataTable();
                OdbcDataAdapter adapter = new OdbcDataAdapter(sql, _conn);
                adapter.Fill(table);
                return table;
            }

            public void Dispose()
            {
                if (_conn != null)
                {
                    _conn.Dispose();
                }
            }
        }
    }

}